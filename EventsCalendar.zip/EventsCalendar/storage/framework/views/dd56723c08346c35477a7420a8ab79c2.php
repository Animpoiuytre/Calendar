<p class="mt-5 mb-3 text-muted">&copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH C:\EventsCalendar\resources\views/auth/partials/copy.blade.php ENDPATH**/ ?>