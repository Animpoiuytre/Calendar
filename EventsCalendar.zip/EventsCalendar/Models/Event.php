<?php

namespace Latfur\Event\Models;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
      
     protected $guarded = ['set_end_date_data'];
}
